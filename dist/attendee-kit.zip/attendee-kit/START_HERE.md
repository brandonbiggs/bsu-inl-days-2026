# Start here

**How to Build Agentic AI Workflows for Research**: a hands-on session using NASA temperature data.

## Before the session

Follow `PREWORK.md`. When `uv run python verify_setup.py` says **All checks PASSED**, you're ready.

## On the day

1. Open a terminal in this folder.
2. Run `uv run python verify_setup.py`.
3. Run `claude`.
4. Open `prompts.md` and copy prompts from it as we go.

## What's here

| File or folder | What it is |
|---|---|
| `prompts.md` | Every prompt we use, in order. **You'll live in this file.** |
| `CLAUDE.md` | Project rules Claude reads automatically. Open it and see. |
| `data/` | Raw NASA GISTEMP data. Never edited. |
| `outputs/` | Everything you and Claude make goes here. |
| `checkpoints/` | Reference results for each stage, if you fall behind. |
| `mcp/` | A small read-only database server for Stage 5. |
| `verify_setup.py` | Checks your setup. |
| `pyproject.toml`, `uv.lock` | The Python packages this kit uses. `uv sync` installs them. |

## Three things to know

- **Your results will differ** from your neighbor's and from the screen. Claude writes new code each time. That's fine.
- **Fallen behind?** Every stage in `prompts.md` has a "Stuck?" prompt that copies the checkpoint into `outputs/`.
- **Claude asks permission** before running commands or editing files. Read what it wants to do, then approve. That habit is part of the lesson.

## The five stages

Setup check, then **plan**, **explore**, **graph**, **3D**, and **MCP**, then apply it to your own research.
